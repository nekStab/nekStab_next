## What is new? 

* tba

## What you may have to change to be compatible 

* tba

## Known Bugs 

[643](https://github.com/Nek5000/Nek5000/issues/643)
[635](https://github.com/Nek5000/Nek5000/issues/635)
[634](https://github.com/Nek5000/Nek5000/issues/634)
[628](https://github.com/Nek5000/Nek5000/issues/628)
[562](https://github.com/Nek5000/Nek5000/issues/562)
[65](https://github.com/Nek5000/Nek5000/issues/65)

## Thanks to our Contributors

We are grateful to all who added new features, filed issues or helped resolve them, asked and answered questions, and were part of inspiring discussions.
